﻿$ErrorActionPreference = "Stop"

try
    {
    #Export GPO
    Write-Output ""
    $output = start-process -FilePath "$PSScriptRoot\LGPO.exe" -ArgumentList "/b","$PSScriptRoot\Export" -NoNewWindow -Wait
    write-output $output
    if ($output -contains "*exited with exit code*")
    {Write-Error "The export process has failed. Please review output for next steps."}
    exit

    }

catch
    {
       $ErrorMessage = $_.Exception.Message
        Write-Error $ErrorMessage
        Break
    }